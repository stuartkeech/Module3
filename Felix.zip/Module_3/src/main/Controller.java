package main;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet("/Controller")
public class Controller extends HttpServlet {	
	private Database db=new Database();
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		HttpSession s=request.getSession();
		s.setAttribute("managerPower",-1);
		String url=request.getHeader("referer");
		String ref=url.substring(url.lastIndexOf("/")+1,url.lastIndexOf(".jsp"));

		String from = request.getParameter("hidden");


		if(ref.equals("RegularClosing")) {
			if(request.getParameter("info").equals("Pending")) {
				db.createConnection();
				s.setAttribute("claims",db.getClaims(null,(int)s.getAttribute("managerPower")));
				db.destroyConnection();
				response.sendRedirect("PolicyClosing.jsp");
			} else if(request.getParameter("info").equals("Approved")) {
				db.createConnection();
				s.setAttribute("claims",db.getClaims(1,(int)s.getAttribute("managerPower")));
				db.destroyConnection();
				response.sendRedirect("PolicyClosing.jsp");
			} else if(request.getParameter("info").equals("Rejected")){
				db.createConnection();
				s.setAttribute("claims",db.getClaims(0,-1));
				db.destroyConnection();
				response.sendRedirect("PolicyClosing.jsp");
			}
		}else if(ref.equals("IntermitentClosing")) {
			if(request.getParameter("info").equals("Pending")) {
				db.createConnection();
				s.setAttribute("claims",db.getClaims(null,(int)s.getAttribute("managerPower")));
				db.destroyConnection();
				response.sendRedirect("PolicyClosing.jsp");
			} else if(request.getParameter("info").equals("Approved")) {
				db.createConnection();
				s.setAttribute("claims",db.getClaims(1,(int)s.getAttribute("managerPower")));
				db.destroyConnection();
				response.sendRedirect("PolicyClosing.jsp");
			} else if(request.getParameter("info").equals("Rejected")){
				db.createConnection();
				s.setAttribute("claims",db.getClaims(0,(int)s.getAttribute("managerPower")));
				db.destroyConnection();
				response.sendRedirect("PolicyClosing.jsp");
			}
		}else if(ref.equals("PolicyAproval")) {
			if(request.getParameter("info").equals("Pending")) {
				db.createConnection();
				s.setAttribute("policies",db.getPolicies(null));
				db.destroyConnection();
				response.sendRedirect("PolicyReview.jsp");
			} else if(request.getParameter("info").equals("Approved")) {
				db.createConnection();
				s.setAttribute("policies",db.getPolicies(1));
				db.destroyConnection();
				response.sendRedirect("PolicyReview.jsp");
			} else if(request.getParameter("info").equals("Rejected")){
				db.createConnection();
				s.setAttribute("policies",db.getPolicies(0));
				db.destroyConnection();
				response.sendRedirect("PolicyReview.jsp");
			}
		}else if(ref.equals("Login")) {
			String button = request.getParameter("loginButton");			
			if(button.equals("Login as Policy Holder")) {
				s.setAttribute("role", "policyHolder");
				s.setAttribute("id", 1);
				response.sendRedirect("Home.jsp");				
			}else if(button.equals("Login as Manager")) {
				s.setAttribute("role", "manager");
				s.setAttribute("id", 1);
				response.sendRedirect("Home.jsp");				
			}else if(button.equals("Login as Admin")) {
				//Redirect the user to AdminManagerNavigation
				s.setAttribute("role", "admin");
				s.setAttribute("id", 1);
				response.sendRedirect("Home.jsp");
			}
		} 
		else if(from.equals("Test")) {
			db.createConnection();
			//Need to use request get attribute of Stuart's Policy Map ID
			s.setAttribute("specificPolicyMap", db.getPolicyMapByPolicyMapId(2));
			PolicyMap specificPolicyMap = db.getPolicyMapByPolicyMapId(2);

			s.setAttribute("specificPolicy", db.getPolicyByPolicyId(specificPolicyMap.getPolicyId()));
			s.setAttribute("specificCustomer", db.getCustomerByCustomerId(specificPolicyMap.getCustomerId()));
			db.destroyConnection();

			response.sendRedirect("Policy.jsp");
		}
		else if(from.equals("Policy")) {
			String inputValue = request.getParameter("policyAction");
			PolicyMap policyMap = null;

			if(inputValue.equals("Confirm")) {
				db.createConnection();
				policyMap = (PolicyMap) s.getAttribute("specificPolicyMap");

				//Checks if it is not already approved
				if(policyMap.getApproved() != 1) {
					db.confirmPolicyMap(policyMap);
					response.sendRedirect("ConfirmingPolicy.jsp");

					db.destroyConnection();
				}
			}
			else if(inputValue.equals("Reject")) {
				//Redirects to Eric's rejection page
				response.sendRedirect("");
			}
			else if(inputValue.equals("Clarification")) {
				response.sendRedirect("Clarification.jsp");
			}
			else if(inputValue.equals("Go back")) {
				response.sendRedirect("Test.jsp");
			}
		}
		else if(from.equals("submitClarification")) {
			String text = request.getParameter("clarification");
			PolicyMap specificPolicyMap = (PolicyMap) s.getAttribute("specificPolicyMap");
			db.createConnection();
			db.submitClarification(text, specificPolicyMap.getPolicyMapId());
			System.out.println(specificPolicyMap.getPolicyId());
			response.sendRedirect("Test.jsp");
			db.destroyConnection();
		}
		else if(from.equals("TestClaim")) {
			db.createConnection();
			//Need to use request get attribute of Stuart's Claim ID
			s.setAttribute("specificClaim", db.getClaimByClaimId(2));
			Claim specificClaim = db.getClaimByClaimId(2);
			s.setAttribute("specificPolicyMap", db.getPolicyMapByPolicyMapId(specificClaim.getPolicyMapId()));
			PolicyMap specificPolicyMap = db.getPolicyMapByPolicyMapId(specificClaim.getPolicyMapId());

			s.setAttribute("specificPolicy", db.getPolicyByPolicyId(specificPolicyMap.getPolicyId()));
			s.setAttribute("specificCustomer", db.getCustomerByCustomerId(specificPolicyMap.getCustomerId()));
			db.destroyConnection();

			response.sendRedirect("Claim.jsp");
		}
		else if(from.equals("Claim")) {
			String inputValue = request.getParameter("claimAction");
			Claim claim = null;

			if(inputValue.equals("Confirm")) {
				db.createConnection();
				claim = (Claim) s.getAttribute("specificClaim");

				//Checks if it is not already approved
				if(claim.getApproved() != 1) {
					db.confirmClaim(claim);
					response.sendRedirect("ConfirmingClaim.jsp");

					db.destroyConnection();
				}
			}
			else if(inputValue.equals("Reject")) {
				//Redirects to Eric's rejection page
				response.sendRedirect("");
			}
			else if(inputValue.equals("Go back")) {
				response.sendRedirect("TestClaim.jsp");
			}
		}
	}
}
