package com;

public class Death {
	
}
