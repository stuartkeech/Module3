/*
 * Created by: Felix
 * Date: Thursday August 16, 2018
 */

package com;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javax.servlet.http.HttpSession;

public class Database {

    private Connection connection;
	private String databaseURL = "jdbc:oracle:thin:@10.101.1.152:1521:xe";
    private String user = "system";
    private String password = "tcs12345";
    private HttpSession session = null;
    
    public void createConnection() throws ClassNotFoundException {
    	try {
    		Class.forName("oracle.jdbc.driver.OracleDriver");
			connection = DriverManager.getConnection(databaseURL, user, password);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}       
    }
    
    public void destroyConnection() {
    	try {
			connection.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch(NullPointerException e2) {
			e2.printStackTrace();
		}
    }
	
	public Policy getPolicyByPolicyId(int policy_ID) {
		Policy policy = null;
		PreparedStatement statement = null;
		ResultSet result = null;
		
		try {
			String query = "SELECT * FROM Policies WHERE policy_ID = ?";
			statement = connection.prepareStatement(query);
			statement.setInt(1, policy_ID);
			result = statement.executeQuery();
			result.next();
			policy = new Policy(result.getInt("policy_id"),result.getString("policy_type"),result.getString("policy_name"),result.getInt("number_nominees"),result.getDouble("tenure"),result.getString("pre_reqs"));
		}
		catch(SQLException e) {
			e.printStackTrace();
		}
		
		return policy;
	}
	
	public PolicyMap getPolicyMapByPolicyMapId(int policy_map_id) {
		PolicyMap policyMap = null;
		PreparedStatement statement = null;
		ResultSet result = null;
		
		try {
			String query = "SELECT * FROM PolicyMap WHERE policy_map_id = ?";
			statement = connection.prepareStatement(query);
			statement.setInt(1, policy_map_id);
			result = statement.executeQuery(query);
			result.next();
			policyMap = new PolicyMap(result.getInt("policy_map_id"), result.getInt("customer_ID"), result.getInt("policy_ID"), result.getInt("agent_ID"), result.getString("start_date"), result.getInt("payments_per_year"), result.getDouble("premium_amount"), result.getString("medical_details"));
		}
		catch(SQLException e) {
			e.printStackTrace();
		}
		
		return policyMap;
	}
	
	public Customer getCustomerByCustomerId(int customer_id) {
		Customer customer = null;
		PreparedStatement statement = null;
		ResultSet result = null;
		
		try {
			String query = "SELECT * FROM Customers WHERE customer_ID = ?";
			statement = connection.prepareStatement(query);
			statement.setInt(1, customer_id);
			result = statement.executeQuery(query);
			result.next();
			customer = new Customer(result.getInt("customer_ID"), result.getString("firstname"), result.getString("middlename"), result.getString("lastname"), result.getString("DOB"), result.getString("gender"), result.getString("occupation"), result.getDouble("salary"), result.getString("marital_status"), result.getInt("number_children"), result.getString("SIN"));
		}
		catch(SQLException e) {
			e.printStackTrace();
		}
		
		return customer;
	}
}
