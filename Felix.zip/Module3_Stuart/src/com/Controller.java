package com;

import java.io.IOException;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class Controller
 */
@WebServlet("/Controller")
public class Controller extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private Database db;

    /**
     * @see HttpServlet#HttpServlet()
     */
    public Controller() {
        super();
        db = new Database();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
		
		HttpSession session = request.getSession(true);

		String from = request.getParameter("hidden");
		
		if(from.equals("Test")) {
			try {
				db.createConnection();
				//Need to use request get attribute of Stuart's Policy Map ID
				session.setAttribute("specificPolicyMap", db.getPolicyMapByPolicyMapId(1));
				PolicyMap specificPolicyMap = db.getPolicyMapByPolicyMapId(1);
				
				session.setAttribute("specificPolicy", db.getPolicyByPolicyId(specificPolicyMap.getPolicyId()));
				session.setAttribute("specificCustomer", db.getCustomerByCustomerId(specificPolicyMap.getCustomerId()));
				db.destroyConnection();
				
				response.sendRedirect("Policy.jsp");
			} catch (ClassNotFoundException e) {
				e.printStackTrace();
			}
		}
		else if(from.equals("Policy")) {
			String inputValue = request.getParameter("policyAction");
			PolicyMap policyMap = null;
			
			if(inputValue.equals("Confirm")) {
				//System.out.println("You confirmed");
				try {
					db.createConnection();
					policyMap = (PolicyMap) session.getAttribute("specificPolicyMap");
					
					//Checks if it is not already approved
					if(policyMap.getApproved() != 1) {
						db.confirmPolicyMap(policyMap);
						response.sendRedirect("ConfirmingPolicy.jsp");
					}
				} catch (ClassNotFoundException e) {
					e.printStackTrace();
				}
			}
			else if(inputValue.equals("Reject")) {
				
			}
			else if(inputValue.equals("Clarification")) {
				
			}
			else if(inputValue.equals("Go back")) {

				response.sendRedirect("Test.jsp");
			}
		}
	}
}
