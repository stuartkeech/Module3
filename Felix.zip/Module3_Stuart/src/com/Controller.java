package com;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class Controller
 */
@WebServlet("/Controller")
public class Controller extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private Database db;

    /**
     * @see HttpServlet#HttpServlet()
     */
    public Controller() {
        super();
        db = new Database();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
		
		HttpSession session = request.getSession(true);

		String from = request.getParameter("hidden");
		
		if(from.equals("Test")) {
			try {
				db.createConnection();
				//Need to use request get attribute of Stuart's Policy Map ID
				session.setAttribute("specificPolicyMap", db.getPolicyMapByPolicyMapId(2));
				PolicyMap specificPolicyMap = db.getPolicyMapByPolicyMapId(2);
				
				session.setAttribute("specificPolicy", db.getPolicyByPolicyId(specificPolicyMap.getPolicyId()));
				session.setAttribute("specificCustomer", db.getCustomerByCustomerId(specificPolicyMap.getCustomerId()));
				db.destroyConnection();
				
				response.sendRedirect("Policy.jsp");
			} catch (ClassNotFoundException e) {
				e.printStackTrace();
			}
		}
		else if(from.equals("Policy")) {
			String inputValue = request.getParameter("policyAction");
			PolicyMap policyMap = null;
			
			if(inputValue.equals("Confirm")) {
				try {
					db.createConnection();
					policyMap = (PolicyMap) session.getAttribute("specificPolicyMap");
					
					//Checks if it is not already approved
					if(policyMap.getApproved() != 1) {
						db.confirmPolicyMap(policyMap);
						response.sendRedirect("ConfirmingPolicy.jsp");
						
					db.destroyConnection();
					}
				} catch (ClassNotFoundException e) {
					e.printStackTrace();
				}
			}
			else if(inputValue.equals("Reject")) {
				//Redirects to Eric's rejection page
				response.sendRedirect("");
			}
			else if(inputValue.equals("Clarification")) {
				response.sendRedirect("Clarification.jsp");
			}
			else if(inputValue.equals("Go back")) {
				response.sendRedirect("Test.jsp");
			}
		}
		else if(from.equals("submitClarification")) {
			String text = request.getParameter("clarification");
			PolicyMap specificPolicyMap = (PolicyMap) session.getAttribute("specificPolicyMap");
			try {
				db.createConnection();
				db.submitClarification(text, specificPolicyMap.getPolicyMapId());
				System.out.println(specificPolicyMap.getPolicyId());
				response.sendRedirect("Test.jsp");
				db.destroyConnection();
			} catch (ClassNotFoundException e) {
				e.printStackTrace();
			}
		}
		else if(from.equals("TestClaim")) {
			try {
				db.createConnection();
				//Need to use request get attribute of Stuart's Claim ID
				session.setAttribute("specificClaim", db.getClaimByClaimId(2));
				Claim specificClaim = db.getClaimByClaimId(2);
				session.setAttribute("specificPolicyMap", db.getPolicyMapByPolicyMapId(specificClaim.getPolicyMapId()));
				PolicyMap specificPolicyMap = db.getPolicyMapByPolicyMapId(specificClaim.getPolicyMapId());
				
				session.setAttribute("specificPolicy", db.getPolicyByPolicyId(specificPolicyMap.getPolicyId()));
				session.setAttribute("specificCustomer", db.getCustomerByCustomerId(specificPolicyMap.getCustomerId()));
				db.destroyConnection();
				
				response.sendRedirect("Claim.jsp");
			} catch (ClassNotFoundException e) {
				e.printStackTrace();
			}
		}
		else if(from.equals("Claim")) {
			String inputValue = request.getParameter("claimAction");
			Claim claim = null;
			
			if(inputValue.equals("Confirm")) {
				try {
					db.createConnection();
					claim = (Claim) session.getAttribute("specificClaim");
					
					//Checks if it is not already approved
					if(claim.getApproved() != 1) {
						db.confirmClaim(claim);
						response.sendRedirect("ConfirmingClaim.jsp");
						
					db.destroyConnection();
					}
				} catch (ClassNotFoundException e) {
					e.printStackTrace();
				}
			}
			else if(inputValue.equals("Reject")) {
				//Redirects to Eric's rejection page
				response.sendRedirect("");
			}
			else if(inputValue.equals("Go back")) {
				response.sendRedirect("TestClaim.jsp");
			}
		}
	}
}
