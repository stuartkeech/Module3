package com;

public class Policy {
	private int policy_id;
	private String policy_type;
	private String policy_name;
	private int number_nominees;
	private double tenure;
	private String pre_reqs;
	
	Policy(int policy_id, String policy_type, String policy_name, int number_nominees, double tenure, String pre_reqs) {
		this.policy_id = policy_id;
		this.policy_type = policy_type;
		this.policy_name = policy_name;
		this.number_nominees = number_nominees;
		this.tenure = tenure;
		this.pre_reqs = pre_reqs;
	}
	
	int getPolicyId() {
		return this.policy_id;
	}
	
	String getPolicyType() {
		return this.policy_type;
	}
	
	String getPolicyName() {
		return this.policy_name;
	}
	
	int getNumberNominees() {
		return this.number_nominees;
	}
	
	double getTenure() {
		return this.tenure;
	}
	
	String getPreReqs() {
		return this.pre_reqs;
	}
	
	void setPolicyId(int policy_id) {
		this.policy_id = policy_id;
	}
	
	void setPolicyType(String policy_type) {
		this.policy_type = policy_type;
	}
	
	void setPolicyName(String policy_name) {
		this.policy_name = policy_name;
	}
	
	void setNumberNominees(int number_nominees) {
		this.number_nominees = number_nominees;
	}
	
	void setTenure(double tenure) {
		this.tenure = tenure;
	}
	
	void setPreReqs(String pre_reqs) {
		this.pre_reqs = pre_reqs;
	}
}
