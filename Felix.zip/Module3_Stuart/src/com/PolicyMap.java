package com;

public class PolicyMap {
	private int policy_map_id;
	private int customer_ID;
	private int policy_ID;
	private int agent_ID;
	private String start_date;
	private int payments_per_year;
	private double premium_amount;
	private String medical_details;
	
	PolicyMap(int policy_map_id, int customer_ID, int policy_ID, int agent_ID, String start_date, int payments_per_year, double premium_amount, String medical_details) {
		this.policy_map_id = policy_map_id;
		this.customer_ID = customer_ID;
		this.policy_ID = policy_ID;
		this.agent_ID = agent_ID;
		this.start_date = start_date;
		this.payments_per_year = payments_per_year;
		this.premium_amount = premium_amount;
		this.medical_details = medical_details;
	}
	
	int getPolicyMapId() {
		return this.policy_map_id;
	}
	
	int getCustomerId() {
		return this.customer_ID;
	}
	
	int getPolicyId() {
		return this.policy_ID;
	}
	
	int getAgentId() {
		return this.agent_ID;
	}
	
	String getStartDate() {
		return this.start_date;
	}
	
	int getPaymentsPerYear() {
		return this.payments_per_year;
	}
	
	double getPremiumAmount() {
		return this.premium_amount;
	}
	
	String getMedicalDetails() {
		return this.medical_details;
	}
	
	void setPolicyMapId(int policy_map_id) {
		this.policy_map_id = policy_map_id;
	}
	
	void setCustomerId(int customer_ID) {
		this.customer_ID = customer_ID;
	}
	
	void setPolicyId(int policy_ID) {
		this.policy_ID = policy_ID;
	}
	
	void setAgentId(int agent_ID) {
		this.agent_ID = agent_ID;
	}
	
	void setStartDate(String start_date) {
		this.start_date = start_date;
	}
	
	void setPaymentsPerYear(int payments_per_year) {
		this.payments_per_year = payments_per_year;
	}
	
	void setPremiumAmount(double premium_amount) {
		this.premium_amount = premium_amount;
	}
	
	void setMedicalDetails(String medical_details) {
		this.medical_details = medical_details;
	}
}
