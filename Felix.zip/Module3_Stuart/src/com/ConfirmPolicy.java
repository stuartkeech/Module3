/*
 * Created by: Felix
 * Date: Wednesday August 15, 2018
 */

package com;

import java.io.IOException;

import javax.servlet.jsp.JspWriter;

public class ConfirmPolicy {
	
	private static String user = "Admin";
	
	//Temporary method that grabs the type of user
	public static String getUser() {
		return user;
	}
	
	//The method that reveals the options
	public static void options(JspWriter out) throws IOException {
		out.println("<button onclick=\"location.href=\'ConfirmPolicy.todo\'\" type=\"button\">Confirm Policy</button>");
		out.println("<button onclick=\"location.href=\'RejectPolicy.todo\'\" type=\"button\">Reject Policy</button>");
		out.println("<button onclick=\"location.href=\'ClarifyPolicy.todo\'\" type=\"button\">Clarify Policy</button>");
	}
}