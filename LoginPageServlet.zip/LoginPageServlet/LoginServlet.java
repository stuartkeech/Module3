package com;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class LoginServlet
 */
@WebServlet("/LoginServlet")
public class LoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.setContentType("text/html");
		
		HttpSession session = request.getSession();
		
		if(request.getParameter("policyHolder").equals("Login as Policy Holder")) {
			session.setAttribute("role", "policyHolder");
			//Redirect the user to PolicyHolderNavigation
			
		}else if(request.getParameter("manager").equals("Login as Manager")) {
			session.setAttribute("role", "manager");
			//Redirect the user to AdminManagerNavigation
			
		}else if(request.getParameter("admin").equals("Login as Admin")) {
			//Redirect the user to AdminManagerNavigation
			session.setAttribute("role", "admin");
		}
	}
}
